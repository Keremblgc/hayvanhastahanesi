﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data.SqlClient;

namespace hayvan_hastahanesi
{
    public partial class arayüz : Form
    {
        public arayüz()
        {
            InitializeComponent();
        }

        private void arayüz_Load(object sender, EventArgs e)
        {
            
            string[] türler = { "Kedi", "Köpek", "Balık", "Kuş", "Kaplumbağa" };
            string[] cinsiyetler = { "dişi", "erkek" };
            string[] veterinerler = { "Ali BOZ", "Zeynep USLU", "Alişan BİLGİÇ", "Erdem Yılmaz" };
            string[] yaslar = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" };
            string[] seanslar = { "08.00", "08.15", "08.30", "08.45", "09.00", "09.15", "09.30", "09.45", "10.00", "10.15", "10.30", "10.45", "11.00", "11.15", "11.30", "11.45", };
            
            //veteriner isimleri
            for (int c = 0; c < 4; c++)
            {
                comboBox1.Items.Add(veterinerler[c]); 
            }

            //seanslar
            for (int s = 0; s < 15; s++)
            {
                seans.Items.Add(seanslar[s]);
            }
           

            //hayvan türleri
            for (int d = 0; d < 5; d++)
            {
                tür.Items.Add(türler[d]);
            }

            //hayvan yaşı
            for (int f= 0; f < 10;f++)
            {
                yas.Items.Add(yaslar[f]);
            }

            //hayvan cinsiyeti
            for (int g = 0; g < 2; g++)
            {
                cinsiyet.Items.Add(cinsiyetler[g]);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int seciliveteriner = comboBox1.SelectedIndex;
            //veterinerlerin list ine ekleme
            if (seciliveteriner==0)
            {
                listBox1.Items.Add(seans.Text + " " + textBox1.Text + " " + textBox2.Text + "-->" + tür.Text);
            }

           else if (seciliveteriner == 1)
            {
                listBox2.Items.Add(seans.Text +" "+ textBox1.Text+" "+textBox2.Text+"-->"+tür.Text);
            }

         else  if (seciliveteriner == 2)
            {
                listBox3.Items.Add(seans.Text + " " + textBox1.Text + " " + textBox2.Text + "-->" + tür.Text);
            }

           else if (seciliveteriner == 3)
            {
                listBox4.Items.Add(seans.Text + " " + textBox1.Text + " " + textBox2.Text + "-->" + tür.Text);
            }

            else
            {
                MessageBox.Show("veteriner seçiniz");
            }



            ////seçili seansı silme
            //int seciliseans = seans.SelectedIndex;
            //seans.Items.RemoveAt(seciliseans);

            //kayıttan sonra verileri silme
            textBox1.Text = "";
            textBox2.Text = "";
            tür.Text = "";
            yas.Text = "";
            cinsiyet.Text = "";
            seans.Text = "";
            comboBox1.Text = "";
            sikayet.Text = "";






        }

        private void button2_Click(object sender, EventArgs e)
        {
            tümhastalar f3 = new tümhastalar();
            f3.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            kayıtekleme f4 = new kayıtekleme();
            f4.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            geçmişhastalar f5 = new geçmişhastalar();
            f5.Show();
        }
    }
}
