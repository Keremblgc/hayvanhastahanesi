﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hayvan_hastahanesi
{
    public partial class girisforum : Form
    {
        public girisforum()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            girisforum f1 = new girisforum();
            f1.Close();
            arayüz f2 = new arayüz();
            f2.Show();
            this.Hide();
        }
    }
}
