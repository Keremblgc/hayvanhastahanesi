﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hayvan_hastahanesi
{
    public partial class kayıtekleme : Form
    {
        public kayıtekleme()
        {
            InitializeComponent();
        }
    }
}
